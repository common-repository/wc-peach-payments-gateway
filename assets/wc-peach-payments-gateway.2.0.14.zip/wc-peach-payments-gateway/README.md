### WC Peach Payments Gateway

```
Contributors: Peach Payments
Tags: woocommerce, payments, credit card, payment request
Requires at least: 4.7
Tested up to: 6.0
Requires PHP: 7.0
Stable tag: 2.0.14
Version: 2.0.13
License: GPLv3
```
