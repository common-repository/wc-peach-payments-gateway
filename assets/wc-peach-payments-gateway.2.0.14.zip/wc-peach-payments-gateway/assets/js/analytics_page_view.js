//alert(merchant.pp_page_title);
gtag('config', 'UA-36515646-5', {
            'page_title': merchant.pp_page_title,
            'groups': 'peach' 
        });