  gtag('js', new Date());
  gtag('event', 'pay_now', {
    'event_category': 'card_widget',
   /* 'event_label': merchant.transaction_id,*/
    'value': '',    
    'send_to' : 'peach'
    });
  
