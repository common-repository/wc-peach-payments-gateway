/*  gtag('js', new Date());
  gtag('event', 'Checkout method for subscription product', {
    'event_category': merchant.siteurl,
    'event_label': merchant.transaction_id,
    'value': '1',    
    'send_to' : 'peach'
    });
 */
  

  gtag('js', new Date());
  gtag('event', 'Checkout method for subscription product', {
    'event_category': 'Assessment Test',
    'event_label': 'Wrong Payment Method',
    'value': '1',
    'send_to' : 'peach'
    });
 