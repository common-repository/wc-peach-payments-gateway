  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-36515646-5', { 'groups': 'peach' });
  gtag('js', new Date());
  gtag('event', 'save', {
    'event_category': 'config_form',
    'event_label': 'success',
    'value': '',    
    'send_to' : 'peach'
    });